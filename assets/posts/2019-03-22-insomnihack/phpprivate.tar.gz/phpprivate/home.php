<?php
$pageContent = <<<CONTENT
<p>It's a private space, only for you. You're free to upload your own data here, none will be able to see them.</p>
<i>Admin</i>
CONTENT;
