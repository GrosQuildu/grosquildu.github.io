#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "maps_helper.h"


typedef unsigned int mapping_diff_result[MAPPING_TYPES_COUNT][64];


mapping* get_addresses(const char* binary_path, struct timespec *ts) {
    pid_t fork_pid = fork();
    if (fork_pid == -1) {
        /* error */
        perror("Error when forking");
        return (mapping*)-1;

    } else if(fork_pid == 0) {
        /* child */
        if(binary_path != NULL) {
            if (execl(binary_path, binary_path, (char*)NULL) == -1) {
                perror("Error executing new binary");
                exit(EXIT_FAILURE);
            }
        }

    } else {
        /* parent */
        nanosleep(ts, NULL); /* wait for the child until it is fully loaded into memory */

        mapping *parsed_maps = parse_map(fork_pid, binary_path);
        if (kill(fork_pid, SIGKILL) == -1) {
            perror("Error killing child process");
            if(parsed_maps != (mapping*)-1)
                free(parsed_maps);
            return (mapping*)-1;
        }
        wait(NULL);
        // printf("%u\n", fork_pid);
        return parsed_maps;
    }
}


void mapping_diff(mapping_diff_result count_ones, unsigned int *count_tests, mapping *b) {
    for (unsigned short i=0; i < b->page_count; i++) {
        count_tests[b->page[i].page_type]++;

        for (int bit_no = 0; bit_no < 64; bit_no++)
        {
            if (((b->page[i].addr_start >> bit_no) & 1) == 1)
                count_ones[b->page[i].page_type][bit_no]++;
        }
    }
}


void print_graph(unsigned int count_ones[64], unsigned int count_tests, unsigned char binary_bits) {
    char levels = 10;
    unsigned char start_space = 15;

    for(char level=levels; level>1; level--) {
        printf("%*s|", start_space, "");
        for(char bit_no=binary_bits-1; bit_no>=0; bit_no--) {
            if (count_ones[bit_no]*levels <= count_tests*level && count_ones[bit_no]*levels > count_tests*(level-1))
                printf("x");
            else
                printf(" ");
        }
        printf("\n");
    }

    /* level zero */
    printf("%*s---|", start_space-3, "");
    for(char bit_no=binary_bits-1; bit_no>=0; bit_no--) {
        if (count_ones[bit_no]*levels <= count_tests)
            printf("x");
        else
            printf("-");
    }
    printf("---\n%*s|\n", start_space, "");
}


void test_get_address(const char *binary_path, struct timespec *ts) {
    mapping *parsed_maps = get_addresses(binary_path, ts);
    if (parsed_maps == (mapping*)-1) {
        exit(EXIT_FAILURE);
    }

    print_map(parsed_maps);
    free(parsed_maps);
    return;
}


void test_aslr(const char *binary_path, bool is_32_bit, struct timespec *ts, unsigned int test_count, unsigned int max_failures) {
    /* Prepare result struct */
    mapping_diff_result count_ones;
    memset(count_ones, 0, sizeof(count_ones));
    unsigned int count_tests[MAPPING_TYPES_COUNT] = {};

    unsigned char binary_bits = 64;
    if (is_32_bit)
        binary_bits = 32;

    /* Run tests*/
    mapping *parsed_maps;
    unsigned int failures;
    unsigned int test_no;
    for (test_no=0, failures=0; failures < max_failures && test_no < test_count; test_no++)
    {
        parsed_maps = get_addresses(binary_path, ts);
        if (parsed_maps == (mapping*)-1) {
            failures++;
        } else {
            mapping_diff(count_ones, count_tests, parsed_maps);
            // print_map(parsed_maps);
            // printf("-----------------\n");
            free(parsed_maps);
        }
    }

    /* Print results */
    printf("[+] Test runs performed: %u\n", test_no);
    printf("[+] test runs failed:    %u\n\n", failures);
    printf("page type -     const bits%*sno. of random bits\n", binary_bits-18, "");
    for (unsigned short page_type=0; page_type < MAPPING_TYPES_COUNT; page_type++) {
        if(page_type == UNKNOWN)
            continue;

        printf("%-10s-     ", page_type_to_str(page_type));
        unsigned char random_bits = 0;

        for(char bit_no=binary_bits-1; bit_no>=0; bit_no--) {
            if(count_ones[page_type][bit_no] == count_tests[page_type]) {
                printf("1");
            } else if(count_ones[page_type][bit_no] == 0) {
                printf("0");
            } else {
                printf("?");
                random_bits++;
            }
        }

        printf("     %u/%u\n", random_bits, binary_bits);
        print_graph(count_ones[page_type], count_tests[page_type], binary_bits);
        printf("\n");

        // if (page_type == VDSO) {
        //     for(char bit_no=binary_bits-1; bit_no>=0; bit_no--) {
        //         printf("%02u - %u\n", bit_no, count_ones[page_type][bit_no]);
        //     }
        //     printf("\n");
        // }
    }
}


bool check_if_32bit(const char *path) {
    FILE *file = fopen(path, "r");
    if (file == NULL) {
        perror("Error opening file for 32-bit test");
        exit(EXIT_FAILURE);
    }

    char buf[6] = {};
    if (fread(buf, 1, 5, file) != 5) {
        perror("Error reading file for 32-bit test");
        exit(EXIT_FAILURE);
    }

    if (fclose(file) == EOF) {
        perror("Error closing file for 32-bit test");
        exit(EXIT_FAILURE);
    }

    if (buf[4] == '\x01')
        return true;
    return false;

}

int main(int argc, char const *argv[]) {   
    /* gcc maps_helper.h test_aslr.c -o test_aslr */

    if(argc != 3) {
        printf("Usage: %s path_to_test_binary number_of_tests\n", argv[0]);
        exit(EXIT_SUCCESS);
    }

    char *binary_path = realpath(argv[1], NULL); /* program for execve, should not exit quickly*/
    if (binary_path == NULL) {
        perror("Error getting absolute path to test binary");
        exit(EXIT_FAILURE);
    }
    bool is_32_bit = check_if_32bit(binary_path);    /* wheter the binary is 32 bit app */

    errno = 0;
    unsigned int test_count = strtol(argv[2], NULL, 10);  /* amount of processes to test */
    if (errno != 0) {
        perror("Error converting number_of_tests to int");
        exit(EXIT_FAILURE);
    }

    unsigned int max_failures = 20;     /* max acceptable amount of failures in `get_address` */
    struct timespec ts = {.tv_sec=0, .tv_nsec=1000000}; /* time for execve to fully loads binary into address space*/

    // test_get_address(binary_path, &ts);
    test_aslr(binary_path, is_32_bit, &ts, test_count, max_failures);

    free(binary_path);
}