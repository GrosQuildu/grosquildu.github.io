#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char const *argv[])
{
    /* gcc main.c -o main && gcc -m32 main.c -o main32 */
    int x = 2;    
    getc(stdin);
    return 0;
}