#ifndef __MAPS_HELPER__
#define __MAPS_HELPER__


#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <errno.h>
#include <stdbool.h>
#include <string.h>


#define MAPPING_TYPES_COUNT 8
typedef enum mapping_types {CODE=0, HEAP, LIBC, LD, STACK, VDSO, VVAR, UNKNOWN} MAPPING_TYPES;
char *mapping_types_str[MAPPING_TYPES_COUNT] = {"code", "[heap]", "libc", "ld", "[stack]", "[vdso]", "[vvar]", "unknown"};


char *page_type_to_str(MAPPING_TYPES mapping_type) {
    return mapping_types_str[mapping_type];
}


MAPPING_TYPES str_to_page_type(char *str) {
    MAPPING_TYPES current_page_type = UNKNOWN;
    if (strstr(str, "[heap]") != NULL)
        current_page_type = HEAP;
    else if (strstr(str, "libc") != NULL)
        current_page_type = LIBC;
    else if (strstr(str, "ld") != NULL)
        current_page_type = LD;
    else if (strstr(str, "[stack]") != NULL)
        current_page_type = STACK;
    else if (strstr(str, "[vvar]") != NULL)
        current_page_type = VVAR;
    else if (strstr(str, "[vdso]") != NULL)
        current_page_type = VDSO;
    return current_page_type;
}

typedef struct one_page {
    MAPPING_TYPES page_type;
    uint64_t addr_start, addr_end;
} one_page;


typedef struct mapping {
    one_page page[MAPPING_TYPES_COUNT];
    short page_count;
} mapping;


void print_map(mapping *map) {
    for (unsigned short i=0; i < map->page_count; i++) {
        printf("%llx - %llx %s\n",
            map->page[i].addr_start,
            map->page[i].addr_end,
            page_type_to_str(map->page[i].page_type));
    }
}


mapping* parse_map(pid_t pid, const char* binary_path) {
    /* Create file path to read for the mapping */
    char file_path[11+22] = {};
    if (snprintf(file_path, 33, "/proc/%u/maps", pid) < 0) {
        perror("Error creating /proc/pid/maps filename");
        return (mapping*)-1;
    }

    /* Open the file */
    FILE *maps_file = fopen(file_path, "r");
    if (maps_file == NULL) {
        perror("Error opening /proc/pid/maps");
        return (mapping*)-1;
    }

    ssize_t nread;
    size_t len = 0;
    char *line = NULL;
    bool is_new_page_type = true;
    mapping *parsed_maps = malloc(sizeof(mapping));
    memset(parsed_maps, 0, sizeof(mapping));

    /*
    Read the file, the format should be:
    address           perms offset  dev   inode       pathname
    00400000-00452000 r-xp 00000000 08:02 173521      /usr/bin/dbus-daemon
    00651000-00652000 r--p 00051000 08:02 173521      /usr/bin/dbus-daemon
    */
    while ((nread = getline(&line, &len, maps_file)) != -1) {
        /* Check what type of page it is now*/
        MAPPING_TYPES current_page_type;
        if (strstr(line, binary_path) != NULL)
            current_page_type = CODE;
        else
            current_page_type = str_to_page_type(line);

        /* Update only if not seen before */
        is_new_page_type = true;
        if (current_page_type == UNKNOWN)
            is_new_page_type = false;

        for (unsigned short i=0; is_new_page_type && i < parsed_maps->page_count; i++) {
            if (parsed_maps->page[i].page_type == current_page_type)
                is_new_page_type = false;
        }

        if (is_new_page_type) {
            /* Get addresses */
            char *endptr = NULL;
            uint64_t addr_start = strtoll(line, &endptr, 16);
            if ((addr_start == LLONG_MIN || addr_start == LONG_MIN) && errno == ERANGE) {
                perror("Error reading start address");
                free(parsed_maps);
                return (mapping*)-1;
            }

            uint64_t addr_end = strtoll(endptr+1, &endptr, 16);
            if ((addr_end == LLONG_MIN || addr_end == LONG_MIN) && errno == ERANGE) {
                perror("Error reading end address");
                free(parsed_maps);
                return (mapping*)-1;
            }

            parsed_maps->page[current_page_type].page_type = current_page_type;
            parsed_maps->page[current_page_type].addr_start = addr_start;
            parsed_maps->page[current_page_type].addr_end = addr_end;
            parsed_maps->page_count++;
        }
    }

    free(line);
    if (fclose(maps_file) == EOF) {
        perror("Error closing the file");
        free(parsed_maps);
        return (mapping*)-1;
    }

    if (parsed_maps->page_count == 0) {
        fprintf(stderr, "No pages readed\n");
        free(parsed_maps);
        return (mapping*)-1;
    }

    return parsed_maps;
}
#endif